package com.smarttech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartTechApplicationTests {

    @Test
    void contextLoads() {
    }

}
