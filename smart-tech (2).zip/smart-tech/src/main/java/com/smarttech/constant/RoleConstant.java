package com.smarttech.constant;

public enum RoleConstant {
    USER, ADMIN
}
