package com.smarttech.constant;

public enum StatisticType {
    MONTH,
    YEAR,
    NONE;
}
